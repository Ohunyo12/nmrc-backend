﻿namespace ReportDeveloper.ReportDataset
{
}

namespace FintrakBanking.APICore.Reports.Credit
{


    public partial class Credit
    {
    }
}
